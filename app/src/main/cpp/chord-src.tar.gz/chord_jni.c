#include <jni.h>
#include <stdlib.h>
#include <stdio.h>
#include "chord.h"

#define UNUSED(x) (void)(x)

// Serializes each segment as "start_sec|end_sec|label" and returns a
// jobjectArray of those strings. Simple and avoids needing a custom JNI
// class/struct mapping just for a handful of fields - Kotlin splits on '|'.
JNIEXPORT jobjectArray JNICALL
Java_com_whispercpp_chord_ChordLib_00024Companion_detectChords(
        JNIEnv *env, jobject thiz, jfloatArray audio_data, jint sample_rate) {
    UNUSED(thiz);

    jfloat *audio = (*env)->GetFloatArrayElements(env, audio_data, NULL);
    const jsize n_samples = (*env)->GetArrayLength(env, audio_data);

    chord_segment_t *segments = NULL;
    const int n_segments = chord_detect(audio, (int) n_samples, (int) sample_rate, &segments);

    (*env)->ReleaseFloatArrayElements(env, audio_data, audio, JNI_ABORT);

    jclass string_class = (*env)->FindClass(env, "java/lang/String");
    if (n_segments <= 0) {
        free(segments);
        return (*env)->NewObjectArray(env, 0, string_class, NULL);
    }

    jobjectArray result = (*env)->NewObjectArray(env, n_segments, string_class, NULL);
    char buf[64];
    for (int i = 0; i < n_segments; i++) {
        snprintf(buf, sizeof(buf), "%.3f|%.3f|%s",
                 segments[i].start_sec, segments[i].end_sec, segments[i].label);
        jstring entry = (*env)->NewStringUTF(env, buf);
        (*env)->SetObjectArrayElement(env, result, i, entry);
        (*env)->DeleteLocalRef(env, entry);
    }

    free(segments);
    return result;
}

// Live/streaming counterpart to detectChords(): classifies exactly one
// frame's worth of audio (see chordFrameLengthSamples below) and returns a
// single label immediately - meant to be called repeatedly from the
// recording thread while audio is still coming in, not just after the fact.
JNIEXPORT jstring JNICALL
Java_com_whispercpp_chord_ChordLib_00024Companion_classifyFrame(
        JNIEnv *env, jobject thiz, jfloatArray frame, jint sample_rate) {
    UNUSED(thiz);

    jfloat *samples = (*env)->GetFloatArrayElements(env, frame, NULL);
    const jsize n_samples = (*env)->GetArrayLength(env, frame);

    char label[8];
    chord_classify_frame(samples, (int) n_samples, (int) sample_rate, label);

    (*env)->ReleaseFloatArrayElements(env, frame, samples, JNI_ABORT);
    return (*env)->NewStringUTF(env, label);
}

JNIEXPORT jint JNICALL
Java_com_whispercpp_chord_ChordLib_00024Companion_chordFrameLengthSamples(
        JNIEnv *env, jobject thiz, jint sample_rate) {
    UNUSED(env);
    UNUSED(thiz);
    return chord_frame_length_samples((int) sample_rate);
}
