#include "chord_hmm.h"
#include "chord_internal.h"

#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdio.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define N_CHORD_STATES 24   // 12 roots x {major, minor}
#define N_STATES       25   // + "N" (no chord)
#define STATE_N        24

// Frames whose total chroma energy is below this multiple of the
// recording's own peak get their emission forced to "N is the only
// plausible state" - handles true silence/near-silence explicitly rather
// than relying on the statistical model to figure it out on its own from a
// mostly-flat, mostly-zero vector (which is numerically fragile).
#define SILENCE_FRACTION_OF_PEAK 0.08
#define SILENCE_FORCED_LOGLIK    (-1e6)

// Segments shorter than this get folded into a neighbor after decoding -
// Viterbi's self-transition bias already discourages rapid flicker, but a
// genuinely short chord (e.g. a quick passing chord) can still produce a
// very short run; below this length it's more likely mis-segmentation than
// a real quick chord change on a phone recording.
#define MIN_SEGMENT_SECONDS 0.35

// How concentrated the "soft template" is on a chord's three expected
// tones vs. spread over the other nine. 0.30 each on the 3 expected tones
// (0.90 total) leaves 0.10 spread over the rest - never exactly zero, so
// log() of the template is always defined and a stray overtone doesn't
// tank the score of the otherwise-correct chord.
#define TEMPLATE_TONE_MASS   0.30

#define EPS 1e-9

// ---- Emission model: P(chroma | state) -------------------------------------------

static double template_dist[N_STATES][N_PITCH_CLASSES];

static void build_templates(void) {
    static const int MAJOR[3] = { 0, 4, 7 };
    static const int MINOR[3] = { 0, 3, 7 };
    const double rest_mass = (1.0 - 3.0 * TEMPLATE_TONE_MASS) / (N_PITCH_CLASSES - 3);

    for (int root = 0; root < N_PITCH_CLASSES; root++) {
        for (int q = 0; q < 2; q++) {
            const int state = q * N_PITCH_CLASSES + root;
            const int * iv = q == 0 ? MAJOR : MINOR;
            int is_tone[N_PITCH_CLASSES] = {0};
            for (int k = 0; k < 3; k++) is_tone[(root + iv[k]) % N_PITCH_CLASSES] = 1;
            for (int i = 0; i < N_PITCH_CLASSES; i++) {
                template_dist[state][i] = is_tone[i] ? TEMPLATE_TONE_MASS : rest_mass;
            }
        }
    }
    // "No chord" state: agnostic/uniform - favored when the chroma vector
    // has no strong tonal concentration anywhere (noise, percussive attack,
    // low-level room tone), same intuition as classic ASR's silence model.
    for (int i = 0; i < N_PITCH_CLASSES; i++) {
        template_dist[STATE_N][i] = 1.0 / N_PITCH_CLASSES;
    }
}

static void state_label(int state, char out[8]) {
    if (state == STATE_N) { strncpy(out, "N", 8); return; }
    const int root  = state % N_PITCH_CLASSES;
    const int minor = state >= N_PITCH_CLASSES;
    snprintf(out, 8, "%s%s", CHORD_NOTE_NAMES[root], minor ? "m" : "");
}

// Cross-entropy-style log-likelihood: how well does this state's template
// distribution explain the observed (normalized) chroma distribution.
// Higher (less negative) = better fit.
static double emission_loglik(int state, const double p[N_PITCH_CLASSES]) {
    double ll = 0.0;
    for (int i = 0; i < N_PITCH_CLASSES; i++) {
        ll += p[i] * log(template_dist[state][i] + EPS);
    }
    return ll;
}

// ---- Transition model: a fixed music-theory prior over chord-to-chord moves -------

static double log_trans[N_STATES][N_STATES];

// Circle-of-fifths distance in fifths-steps (0..6) between two pitch
// classes. 7 is its own inverse mod 12 (7*7 = 49 = 1 mod 12), so
// multiplying the semitone difference by 7 mod 12 converts "steps of a
// semitone" into "steps around the circle of fifths".
static int cof_distance(int root_a, int root_b) {
    const int d = ((root_b - root_a) % 12 + 12) % 12;
    const int steps = (d * 7) % 12;
    return steps < 12 - steps ? steps : 12 - steps;
}

static void build_transitions(void) {
    const double SELF_PROB   = 0.90;  // chords hold for many consecutive frames
    const double FIFTH_DECAY = 0.55;  // affinity decays with circle-of-fifths distance
    const double RELATIVE_BONUS = 2.5; // relative major/minor (e.g. C <-> Am) extra pull
    const double PARALLEL_BONUS = 1.3; // same root, other quality (e.g. C <-> Cm)
    const double N_AFFINITY     = 1.0; // baseline pull to/from "no chord" (onsets/pauses)

    for (int from = 0; from < N_STATES; from++) {
        double weight[N_STATES];
        double weight_sum = 0.0;

        for (int to = 0; to < N_STATES; to++) {
            if (to == from) { weight[to] = 0.0; continue; }

            double w;
            if (from == STATE_N || to == STATE_N) {
                w = N_AFFINITY;
            } else {
                const int root_from   = from % N_PITCH_CLASSES;
                const int minor_from  = from >= N_PITCH_CLASSES;
                const int root_to     = to % N_PITCH_CLASSES;
                const int minor_to    = to >= N_PITCH_CLASSES;

                w = pow(FIFTH_DECAY, cof_distance(root_from, root_to));

                if (root_from == root_to && minor_from != minor_to) {
                    w += PARALLEL_BONUS; // C -> Cm
                }
                // relative major/minor: minor root is major root - 3 semitones
                const int rel_minor_of_from = ((root_from - 3) % 12 + 12) % 12;
                const int rel_major_of_from = (root_from + 3) % 12;
                if (!minor_from && minor_to && root_to == rel_minor_of_from) {
                    w += RELATIVE_BONUS; // C -> Am
                }
                if (minor_from && !minor_to && root_to == rel_major_of_from) {
                    w += RELATIVE_BONUS; // Am -> C
                }
            }
            weight[to] = w;
            weight_sum += w;
        }

        for (int to = 0; to < N_STATES; to++) {
            const double prob = (to == from)
                ? SELF_PROB
                : (1.0 - SELF_PROB) * (weight_sum > 0 ? weight[to] / weight_sum : 1.0 / (N_STATES - 1));
            log_trans[from][to] = log(prob + EPS);
        }
    }
}

static int models_ready = 0;
static void ensure_models(void) {
    if (!models_ready) {
        build_templates();
        build_transitions();
        models_ready = 1;
    }
}

// ---- Viterbi ------------------------------------------------------------------

int chord_decode_hmm(const float * samples, int n_samples, int sample_rate, chord_segment_t ** out_segments) {
    if (n_samples <= 0 || sample_rate <= 0 || samples == NULL || out_segments == NULL) {
        return -1;
    }
    ensure_models();

    const int frame_len = (int) (FRAME_SECONDS * sample_rate);
    const int hop_len    = (int) (frame_len * HOP_FRACTION);
    if (frame_len <= 0 || hop_len <= 0 || n_samples < frame_len) {
        *out_segments = NULL;
        return 0;
    }
    const int n_frames = (n_samples - frame_len) / hop_len + 1;
    if (n_frames <= 0) {
        *out_segments = NULL;
        return 0;
    }

    const float * window = chord_get_window(frame_len);
    float * windowed = (float *) malloc(sizeof(float) * frame_len);
    double * emit = (double *) malloc(sizeof(double) * n_frames * N_STATES);
    if (!windowed || !emit) {
        free(windowed); free(emit);
        return -1;
    }

    // Pass 1: chroma -> per-frame emission log-likelihoods for every state.
    double peak_energy = 0.0;
    double * frame_energy = (double *) malloc(sizeof(double) * n_frames);
    if (!frame_energy) { free(windowed); free(emit); return -1; }

    for (int f = 0; f < n_frames; f++) {
        const int offset = f * hop_len;
        for (int i = 0; i < frame_len; i++) windowed[i] = samples[offset + i] * window[i];

        double chroma[N_PITCH_CLASSES];
        chord_compute_chroma(windowed, frame_len, sample_rate, chroma);

        double total = 0.0;
        for (int i = 0; i < N_PITCH_CLASSES; i++) total += chroma[i];
        frame_energy[f] = total;
        if (total > peak_energy) peak_energy = total;

        double p[N_PITCH_CLASSES];
        for (int i = 0; i < N_PITCH_CLASSES; i++) p[i] = total > EPS ? chroma[i] / total : 1.0 / N_PITCH_CLASSES;

        for (int s = 0; s < N_STATES; s++) {
            emit[f * N_STATES + s] = emission_loglik(s, p);
        }
    }

    const double silence_floor = peak_energy * SILENCE_FRACTION_OF_PEAK;
    for (int f = 0; f < n_frames; f++) {
        if (frame_energy[f] < silence_floor) {
            for (int s = 0; s < N_STATES; s++) {
                emit[f * N_STATES + s] = (s == STATE_N) ? 0.0 : SILENCE_FORCED_LOGLIK;
            }
        }
    }
    free(frame_energy);
    free(windowed);

    // Pass 2: Viterbi DP.
    double * delta = (double *) malloc(sizeof(double) * n_frames * N_STATES);
    int    * psi   = (int *)    malloc(sizeof(int)    * n_frames * N_STATES);
    if (!delta || !psi) { free(emit); free(delta); free(psi); return -1; }

    for (int s = 0; s < N_STATES; s++) {
        delta[s] = log(1.0 / N_STATES) + emit[s];
        psi[s] = -1;
    }
    for (int f = 1; f < n_frames; f++) {
        for (int s = 0; s < N_STATES; s++) {
            double best = -1e300;
            int best_prev = 0;
            for (int sp = 0; sp < N_STATES; sp++) {
                const double v = delta[(f - 1) * N_STATES + sp] + log_trans[sp][s];
                if (v > best) { best = v; best_prev = sp; }
            }
            delta[f * N_STATES + s] = best + emit[f * N_STATES + s];
            psi[f * N_STATES + s] = best_prev;
        }
    }
    free(emit);

    int * path = (int *) malloc(sizeof(int) * n_frames);
    if (!path) { free(delta); free(psi); return -1; }

    int last_state = 0;
    double best_final = -1e300;
    for (int s = 0; s < N_STATES; s++) {
        if (delta[(n_frames - 1) * N_STATES + s] > best_final) {
            best_final = delta[(n_frames - 1) * N_STATES + s];
            last_state = s;
        }
    }
    path[n_frames - 1] = last_state;
    for (int f = n_frames - 2; f >= 0; f--) {
        path[f] = psi[(f + 1) * N_STATES + path[f + 1]];
    }
    free(delta);
    free(psi);

    // Pass 3: run-length encode the decoded state path into segments.
    chord_segment_t * segments = (chord_segment_t *) malloc(sizeof(chord_segment_t) * n_frames);
    int n_segments = 0;
    int prev_state = -1;
    for (int f = 0; f < n_frames; f++) {
        const double t_start = (f * hop_len) / (double) sample_rate;
        const double t_end   = t_start + frame_len / (double) sample_rate;
        if (n_segments > 0 && path[f] == prev_state) {
            segments[n_segments - 1].end_sec = t_end;
        } else {
            segments[n_segments].start_sec = t_start;
            segments[n_segments].end_sec   = t_end;
            state_label(path[f], segments[n_segments].label);
            n_segments++;
        }
        prev_state = path[f];
    }
    free(path);

    // Pass 4: fold too-short segments into a neighbor, then coalesce any
    // resulting adjacent-equal-label runs (same approach as before).
    for (int i = 0; i < n_segments; i++) {
        const double len = segments[i].end_sec - segments[i].start_sec;
        if (len < MIN_SEGMENT_SECONDS && n_segments > 1) {
            if (i + 1 < n_segments) {
                segments[i + 1].start_sec = segments[i].start_sec;
            } else {
                segments[i - 1].end_sec = segments[i].end_sec;
            }
            memmove(&segments[i], &segments[i + 1], sizeof(chord_segment_t) * (n_segments - i - 1));
            n_segments--;
            i--;
        }
    }
    for (int i = 1; i < n_segments; ) {
        if (strcmp(segments[i - 1].label, segments[i].label) == 0) {
            segments[i - 1].end_sec = segments[i].end_sec;
            memmove(&segments[i], &segments[i + 1], sizeof(chord_segment_t) * (n_segments - i - 1));
            n_segments--;
        } else {
            i++;
        }
    }

    *out_segments = segments;
    return n_segments;
}
