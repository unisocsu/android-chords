#ifndef WHISPER_ANDROID_CHORD_HMM_H
#define WHISPER_ANDROID_CHORD_HMM_H

#include "chord.h"

#ifdef __cplusplus
extern "C" {
#endif

// Statistical (HMM + Viterbi) chord sequence decoder.
//
// This is the general statistical technique from Bello & Pickens, "A Robust
// Mid-Level Representation For Harmonic Content In Music Signals" (ISMIR
// 2005) - reimplemented from scratch here (own emission/transition model,
// no code or trained parameters taken from any existing implementation).
//
// Unlike a per-frame classifier, this looks at the WHOLE chroma sequence at
// once and finds the single most probable chord sequence given:
//   - an emission model: how well each frame's chroma vector matches each
//     of the 25 chord states (24 major/minor triads + "no chord"), modeled
//     as a cross-entropy-style log-likelihood against a soft template
//     (a real probability distribution over pitch classes, not a hard mask)
//   - a transition model: a musical prior over which chord is likely to
//     follow which - strong self-persistence (chords hold for many frames),
//     and higher probability toward circle-of-fifths-close chords and
//     relative major/minor pairs than to musically unrelated ones.
//
// This needs no model file/weights - the transition model is a fixed,
// hand-specified music-theory prior (not learned from data), and the
// emission model is a closed-form function of the chroma vector. It costs
// O(n_frames * 25^2) time and O(n_frames * 25) memory, both trivial even on
// very old/slow hardware for any recording length you'd realistically make
// on a phone.
//
// Returns the number of segments and a newly malloc'd array via
// *out_segments (caller must free() it), or -1 on error.
int chord_decode_hmm(
        const float * samples,
        int            n_samples,
        int            sample_rate,
        chord_segment_t ** out_segments);

#ifdef __cplusplus
}
#endif

#endif //WHISPER_ANDROID_CHORD_HMM_H
