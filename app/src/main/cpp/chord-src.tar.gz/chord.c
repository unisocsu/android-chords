#include "chord.h"
#include "chord_internal.h"
#include "chord_hmm.h"

#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdio.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// ---- Tunable analysis constants -------------------------------------------------
// Frame length chosen so even the lowest note (C2, ~65Hz) gets many cycles of
// signal to analyze (0.25s * 65Hz ~= 16 cycles) - needed for the Goertzel
// filter to separate it cleanly from its neighbors.
#define MIDI_LOW            36     // C2
#define MIDI_HIGH           95     // B6

// Used only by the simple *live* per-frame classifier (see
// chord_classify_frame below) - the batch path's real decision-making is
// now chord_decode_hmm() in chord_hmm.c, which doesn't use a hard threshold
// like this at all.
#define MIN_MATCH_FRACTION  0.55

const char * CHORD_NOTE_NAMES[N_PITCH_CLASSES] = {
        "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"
};

// Triads only (major/minor). Extending to 7ths/sus later is just more rows here.
typedef struct {
    const char * quality_suffix;
    int          intervals[3];
} chord_template_t;

static const chord_template_t TEMPLATES[2] = {
        { "",  { 0, 4, 7 } }, // major
        { "m", { 0, 3, 7 } }, // minor
};

static double midi_to_freq(int midi) {
    return 440.0 * pow(2.0, (midi - 69) / 12.0);
}

// Generalized Goertzel: magnitude of the DTFT of `x` (already windowed) at
// an arbitrary target frequency - doesn't need to land on an FFT bin, which
// matters here since we want musically-spaced (semitone) frequencies, not
// linearly-spaced FFT bins.
static double goertzel_mag(const float * x, int n, double sample_rate, double target_freq) {
    const double w      = 2.0 * M_PI * target_freq / sample_rate;
    const double cosine = cos(w);
    const double coeff  = 2.0 * cosine;
    double q0 = 0.0, q1 = 0.0, q2 = 0.0;
    for (int i = 0; i < n; i++) {
        q0 = coeff * q1 - q2 + x[i];
        q2 = q1;
        q1 = q0;
    }
    const double real = q1 - q2 * cosine;
    const double imag = q2 * sin(w);
    return sqrt(real * real + imag * imag);
}

// Computes a 12-bin chroma vector for one windowed frame. Per pitch class we
// take the MAX magnitude across its octaves (not the sum) so a note that
// happens to have a strong 2nd or 3rd harmonic lined up with another pitch
// class doesn't get double-counted as if two notes were sounding.
void chord_compute_chroma(const float * windowed_frame, int frame_len, double sample_rate, double chroma[N_PITCH_CLASSES]) {
    for (int pc = 0; pc < N_PITCH_CLASSES; pc++) {
        chroma[pc] = 0.0;
    }
    for (int midi = MIDI_LOW; midi <= MIDI_HIGH; midi++) {
        const double freq = midi_to_freq(midi);
        const double mag  = goertzel_mag(windowed_frame, frame_len, sample_rate, freq);
        const int pc = midi % N_PITCH_CLASSES;
        if (mag > chroma[pc]) {
            chroma[pc] = mag;
        }
    }
}

// Small cache so a live/streaming caller invoking chord_classify_frame()
// repeatedly (e.g. every 250ms while recording) doesn't recompute the Hann
// window every single call, and so the batch path (which builds many frames
// at once) can reuse the same helper.
// NOT thread-safe for concurrent calls from multiple threads at once - fine
// here since chord analysis only ever runs on one thread at a time.
static float * cached_window = NULL;
static int     cached_window_len = 0;

const float * chord_get_window(int frame_len) {
    if (cached_window_len != frame_len) {
        free(cached_window);
        cached_window = (float *) malloc(sizeof(float) * frame_len);
        for (int i = 0; i < frame_len; i++) {
            cached_window[i] = (float) (0.5 - 0.5 * cos(2.0 * M_PI * i / (frame_len - 1)));
        }
        cached_window_len = frame_len;
    }
    return cached_window;
}

int chord_frame_length_samples(int sample_rate) {
    return (int) (FRAME_SECONDS * sample_rate);
}

// Simple hard-threshold per-frame classifier - deliberately kept dumb and
// fast, used ONLY for the live on-screen preview while recording (see
// ChordDetector.classifyFrameBlocking / Recorder's onLiveChord). It has no
// notion of what came before/after, unlike chord_decode_hmm() below, which
// is what the final merged transcript (after recording stops) actually uses.
int chord_classify_frame(const float * samples, int n_samples, int sample_rate, char out_label[8]) {
    const int frame_len = chord_frame_length_samples(sample_rate);
    if (n_samples != frame_len) {
        strncpy(out_label, "N", 8);
        return 0;
    }

    const float * window = chord_get_window(frame_len);
    float * windowed = (float *) malloc(sizeof(float) * frame_len);
    if (!windowed) {
        strncpy(out_label, "N", 8);
        return 0;
    }
    for (int i = 0; i < frame_len; i++) {
        windowed[i] = samples[i] * window[i];
    }

    double chroma[N_PITCH_CLASSES];
    chord_compute_chroma(windowed, frame_len, sample_rate, chroma);
    free(windowed);

    double total = 0.0;
    for (int i = 0; i < N_PITCH_CLASSES; i++) total += chroma[i];
    if (total <= 0.0) {
        strncpy(out_label, "N", 8);
        return 0;
    }

    double best_match_fraction = -1.0;
    int best_root = -1, best_quality = -1;
    for (int root = 0; root < N_PITCH_CLASSES; root++) {
        for (int q = 0; q < 2; q++) {
            double signal_energy = 0.0;
            for (int k = 0; k < 3; k++) {
                signal_energy += chroma[(root + TEMPLATES[q].intervals[k]) % N_PITCH_CLASSES];
            }
            const double match_fraction = signal_energy / total;
            if (match_fraction > best_match_fraction) {
                best_match_fraction = match_fraction;
                best_root = root;
                best_quality = q;
            }
        }
    }

    if (best_match_fraction < MIN_MATCH_FRACTION) {
        strncpy(out_label, "N", 8);
        return 0;
    }
    snprintf(out_label, 8, "%s%s", CHORD_NOTE_NAMES[best_root], TEMPLATES[best_quality].quality_suffix);
    return 1;
}

// The batch entry point now just delegates to the statistical HMM/Viterbi
// decoder - see chord_hmm.c. Kept as a separate function name (rather than
// renaming chord_detect everywhere) so the public API in chord.h is stable.
int chord_detect(const float * samples, int n_samples, int sample_rate, chord_segment_t ** out_segments) {
    return chord_decode_hmm(samples, n_samples, sample_rate, out_segments);
}
