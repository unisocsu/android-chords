#ifndef WHISPER_ANDROID_CHORD_H
#define WHISPER_ANDROID_CHORD_H

#ifdef __cplusplus
extern "C" {
#endif

// One detected, stability-filtered chord region.
typedef struct {
    double start_sec;
    double end_sec;
    char   label[8];   // e.g. "C", "C#m", "N" (no chord / silence / ambiguous)
} chord_segment_t;

// Analyzes mono float32 PCM in [-1, 1] at `sample_rate` Hz using a
// chromagram + expected-tone template match (the general technique from
// Stark & Plumbley, "Real-Time Chord Recognition For Live Performance",
// ICMC 2009 - reimplemented from scratch here, no code borrowed from any
// existing GPL implementation of that paper).
//
// No model file, no weights, no download - this is signal processing only,
// so it costs essentially nothing extra in RAM or APK size on top of whisper.
//
// Returns the number of segments and a newly malloc'd array via
// *out_segments (caller must free() it), or -1 on error (e.g. n_samples <= 0).
int chord_detect(
        const float * samples,
        int            n_samples,
        int            sample_rate,
        chord_segment_t ** out_segments);

// One-shot classification of a single analysis window - the primitive both
// the batch chord_detect() and a live/streaming caller can use. `samples`
// must be exactly one frame's worth (see chord_frame_length_samples()) of
// mono float32 PCM in [-1, 1]; the caller owns windowing/buffering.
// Writes "N" to out_label (and returns 0) for silence/no clear chord,
// otherwise writes a label like "C#m" and returns 1.
int chord_classify_frame(const float * samples, int n_samples, int sample_rate, char out_label[8]);

// Frame length (in samples) chord_classify_frame() expects for this
// sample_rate - exposed so a live/streaming caller can size its rolling
// buffer correctly instead of hardcoding FRAME_SECONDS on the Kotlin side too.
int chord_frame_length_samples(int sample_rate);

#ifdef __cplusplus
}
#endif

#endif //WHISPER_ANDROID_CHORD_H
